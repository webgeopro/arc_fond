<?php

/**
 * XUpload
 * @author Tudor Ilisoi
 * @link http://www.teachmejoomla.net
 * 
 */
class XUploadWidget extends CWidget {

    public $parent_id = 0;
    public $parent_class_id = 0;
    public $mark_as_temp = 1;
    public $relation;
    public $button_text = 'Adăugare fotografii';

    public function init() {
        $this->publishAssets();
    }

    public function run() {
        $parent_class = FlexCore::ClassName($this->parent_class_id);
        $parent_model = new $parent_class;
        $parent_model->with($this->relation);
//        var_dump($parent_model->relations());
//        get upload class by relation
        $relations = $parent_model->relations();
        $my_class = $relations[$this->relation][1]; //model class
        $model = new $my_class;

        Yii::app()->clientScript->registerScript(__CLASS__ . '_go', "
        /*global $ */
$(function () {
    $('.xupload-form').fileUploadUI({
        uploadTable: $('#files'),
        downloadTable: $('#files'),
        buildUploadRow: function (files, index) {
        var short_name = files[index].name.split('\\\').pop().split('/').pop();

            return $('<tr><td>' + short_name + '<\/td>' +
                    '<td class=\"file_upload_progress\"><div><\/div><\/td>' +
                    '<td class=\"file_upload_cancel\">' +
                    '<button class=\"ui-state-default ui-corner-all\" title=\"Anulează\">' +
                    '<span class=\"ui-icon ui-icon-cancel\">Anulează<\/span>' +
                    '<\/button><\/td><\/tr>');
        },
        buildDownloadRow: function (file) {
          // return $('<tr><td>' + file.name + '<\/td><\/tr>');
           return '';

        },
       
onComplete: function (event, files, index, xhr, handler) {
             refreshUploads(window.xuploads_refresh_url,'Aşteptaţi');
        },


       onCompleteAll: function(files){
        alert('all done');
   //     refreshUploads(window.xuploads_refresh_url,'Aşteptaţi');
        },
        onAbort: function (event, files, index, xhr, handler) {
            handler.removeNode(handler.uploadRow);
            
        }


    });
});

                "//,                CClientScript::POS_HEAD
        );

        //    refresh uploads func

        Yii::app()->clientScript->registerScript(
                'xuploads_refresh_url',
                "window.xuploads_refresh_url="
                . CJavaScript::encode(
                        Yii::app()->createUrl('xuploads/upload/index',
                                array(
                                    'parent_id' => $this->parent_id ? $this->parent_id : 0,
                                    'class_id' => FlexCore::ClassId($my_class),
                                )
                        )
                )
                . ";"
                , CClientScript::POS_HEAD
        );





        Yii::app()->clientScript->registerScript(
                'xuploads_refresh_func',
                "

function handleAjax(data){
        \$('#ajax_uploads').html(data);
        \$('#ajax_uploads').unmask();
        \$('.xupload_action').click(function(e){
        e.preventDefault();
        refreshUploads($(this).attr('href'),'Aşteptaţi');
        return false;
        });

      }
function refreshUploads(ajax_url,message){
\$('#ajax_uploads').mask(message);
\$.ajax({ url: ajax_url, context: document.body, success: function(data){handleAjax(data);},error: function(data){handleAjax(data);} });
//return true;
};

"
                , CClientScript::POS_HEAD
        );


        Yii::app()->clientScript->registerScript(
                'xuploads_auto_refresh',
                "refreshUploads(window.xuploads_refresh_url,'Aşteptaţi');"
                , CClientScript::POS_READY
        );





//        echo CHtml::fileField('XUploads', '', array());
        $action = Yii::app()->createUrl('xuploads/upload/upload',
                        array(
                            'parent_id' => $this->parent_id,
                            'parent_class_id' => $this->parent_class_id,
                            'relation' => $this->relation,
                            'mark_as_temp' => $this->mark_as_temp,
                ));
?>


<?php echo CHtml::form($action, 'post', array('enctype' => 'multipart/form-data', 'class' => 'xupload-form')); ?>

<?php echo CHtml::activeFileField($model, 'server_name', array('multiple' => 'multiple')); ?>
        <div><?php echo GxHtml::encode($this->button_text) ?></div>
<?php echo CHtml::endForm(); ?>
        <table id="files"></table>

<?php
    }

    public function publishAssets() {
        $assets = dirname(__FILE__) . '/assets';
        $baseUrl = Yii::app()->assetManager->publish($assets);
        if (is_dir($assets)) {
            Yii::app()->clientScript->registerCoreScript('jquery');
            Yii::app()->clientScript->registerCoreScript('jquery.ui');
            Yii::app()->clientScript->registerScriptFile($baseUrl . '/fileupload-ui/jquery.fileupload.js', CClientScript::POS_HEAD);
            Yii::app()->clientScript->registerScriptFile($baseUrl . '/fileupload-ui/jquery.fileupload-ui.js', CClientScript::POS_HEAD);
            Yii::app()->clientScript->registerCssFile($baseUrl . '/fileupload-ui/jquery.fileupload-ui.css');
            Yii::app()->clientScript->registerCssFile($baseUrl . '/xuploads.css');
        } else {
            throw new Exception('XUpload - Error: Couldn\'t find assets to publish.');
        }
    }

}